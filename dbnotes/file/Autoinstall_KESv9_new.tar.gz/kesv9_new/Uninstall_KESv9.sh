#!/bin/bash

# --------------------------------------------------------------------------------
# NAME
#    Auto_Uninstall_kes.sh
# DESCRIPTION
#    Uninstall_kes, for Linux [Centos7.X && KylinV10 && openEuler24(X86_64/ARM64)]  
# AUTHOR
#    Written by AmberWu  @20251024 
# --------------------------------------------------------------------------------

work_dir=$(cd `dirname $0`;pwd) 
cd ${work_dir} 
. ${work_dir}/conf/dbconfig.ini 

printf "1. 检查是否以root执行此脚本？ \n"
  if [ $USER != "root" ]; then
      printf "[WARNING] The user must be root, but now your user is $USER, please su to root."
      exit 1
  else
      printf "确认以root运行, OK... \n"
  fi
echo 

printf  "2. 开始停止相关的服务... \n"
service kingbased status                  >>/dev/null 2>&1 
service kingbased stop                    >>/dev/null 2>&1 
ps -ef|grep kingbase |grep -v grep |awk '{print $2}' |xargs kill -9    >>/dev/null 2>&1 
echo 

printf  "3. 开始卸载相关的服务... \n"
${DB_HOME}/install/script/rootuninstall.sh          >>/dev/null 2>&1 
${DB_HOME}/Uninstall/Uninstaller                    >>/dev/null 2>&1
su - kingbase -c "${DB_HOME}/startUninstall.sh -i silent"        >>/dev/null 2>&1
echo 

printf  "4. 开始删除相关的文件/文件夹/用户... \n"
rm -rf  ${DB_HOME}                       >>/dev/null 2>&1 
rm -rf  ${DB_DATA}.bak                   >>/dev/null 2>&1 
mv -f ${DB_DATA}  ${DB_DATA}.bak         >>/dev/null 2>&1 
userdel -r kingbase                      >>/dev/null 2>&1 
echo 

printf  "5.  卸载 完成 !!!   \n"
echo 
